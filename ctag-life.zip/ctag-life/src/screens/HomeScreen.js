import React, { useMemo } from 'react';
import { SafeAreaView, StyleSheet, Text, View, TouchableOpacity, ScrollView } from 'react-native';

export default function HomeScreen() {
  const weeklyTrend = useMemo(() => [62, 68, 72, 74, 71, 76, 78], []);

  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.logo}>CTAG LIFE</Text>
          <TouchableOpacity style={styles.profileBadge}>
            <Text style={styles.profileText}>Level A</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.scoreCard}>
          <Text style={styles.scoreTitle}>오늘의 탄소 점수</Text>
          <View style={styles.scoreRow}>
            <Text style={styles.scoreValue}>78</Text>
            <Text style={styles.scoreUnit}> / 100</Text>
          </View>
          <Text style={styles.scoreFeedback}>🌱 상위 15%의 훌륭한 친환경 라이프</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>오늘의 인사이트</Text>
          <Text style={styles.cardDesc}>점심시간 텀블러 사용으로 탄소 30g 절감 달성</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>주간 점수 흐름</Text>
          <View style={styles.chartRow}>
            {weeklyTrend.map((value, index) => (
              <View key={`bar-${index}`} style={styles.chartItem}>
                <View style={[styles.chartBar, { height: value * 1.2 }]} />
                <Text style={styles.chartLabel}>{['월', '화', '수', '목', '금', '토', '일'][index]}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.doubleRow}>
          <View style={[styles.card, styles.halfCard]}>
            <Text style={styles.cardTitle}>절감량</Text>
            <Text style={styles.metricValue}>120g</Text>
            <Text style={styles.metricSub}>이번 주 누적</Text>
          </View>
          <View style={[styles.card, styles.halfCard]}>
            <Text style={styles.cardTitle}>랭킹</Text>
            <Text style={styles.metricValue}>#12</Text>
            <Text style={styles.metricSub}>친구 그룹 기준</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#FFFFFF' },
  scrollContent: { padding: 20, paddingBottom: 28 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 24,
  },
  logo: { fontSize: 24, fontWeight: '900', color: '#2E8B57' },
  profileBadge: {
    backgroundColor: '#F0F8F5',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
  },
  profileText: { color: '#2E8B57', fontWeight: '700' },
  scoreCard: {
    backgroundColor: '#2E8B57',
    borderRadius: 24,
    padding: 28,
    alignItems: 'center',
    marginBottom: 16,
  },
  scoreTitle: { color: '#DFF4E7', fontSize: 16, marginBottom: 8 },
  scoreRow: { flexDirection: 'row', alignItems: 'baseline' },
  scoreValue: { color: '#FFFFFF', fontSize: 56, fontWeight: '900' },
  scoreUnit: { color: '#FFFFFF', fontSize: 20, fontWeight: '600' },
  scoreFeedback: { color: '#FFFFFF', fontSize: 14, marginTop: 12, fontWeight: '700' },
  card: {
    backgroundColor: '#F9F9F9',
    borderRadius: 18,
    padding: 20,
    borderWidth: 1,
    borderColor: '#ECECEC',
    marginBottom: 16,
  },
  cardTitle: { fontSize: 16, fontWeight: '800', color: '#1F2933', marginBottom: 8 },
  cardDesc: { fontSize: 15, color: '#667085', lineHeight: 22 },
  chartRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    marginTop: 8,
    height: 120,
  },
  chartItem: { alignItems: 'center', width: '13%' },
  chartBar: { width: 18, backgroundColor: '#2E8B57', borderRadius: 10, marginBottom: 8 },
  chartLabel: { fontSize: 12, color: '#667085' },
  doubleRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 },
  halfCard: { flex: 1 },
  metricValue: { fontSize: 28, fontWeight: '900', color: '#2E8B57', marginTop: 2 },
  metricSub: { color: '#667085', marginTop: 4 },
});
