import React from 'react';
import { SafeAreaView, StyleSheet, Text, View, ScrollView } from 'react-native';

export default function RewardScreen() {
  const rewards = [
    { title: '친환경 제휴카드 포인트', status: '1,240P 적립 가능' },
    { title: '보험사 친환경 할인', status: '다음 달 3% 할인 예상' },
    { title: '리필스테이션 쿠폰', status: '2장 사용 가능' },
  ];

  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>나의 리워드</Text>
        <Text style={styles.subtitle}>친환경 행동으로 받은 혜택을 모아봤어.</Text>

        {rewards.map((item) => (
          <View key={item.title} style={styles.card}>
            <Text style={styles.cardTitle}>{item.title}</Text>
            <Text style={styles.cardDesc}>{item.status}</Text>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#FFFFFF' },
  scrollContent: { padding: 20, paddingBottom: 28 },
  title: { fontSize: 24, fontWeight: '900', color: '#1F2933', marginTop: 12, marginBottom: 6 },
  subtitle: { fontSize: 15, color: '#7A8894', marginBottom: 18 },
  card: {
    backgroundColor: '#F9F9F9',
    borderRadius: 18,
    padding: 20,
    borderWidth: 1,
    borderColor: '#ECECEC',
    marginBottom: 16,
  },
  cardTitle: { fontSize: 16, fontWeight: '800', color: '#1F2933', marginBottom: 8 },
  cardDesc: { fontSize: 15, color: '#667085', lineHeight: 22 },
});
