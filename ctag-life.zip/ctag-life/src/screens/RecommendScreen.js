import React from 'react';
import { SafeAreaView, StyleSheet, Text, View, ScrollView } from 'react-native';

export default function RecommendScreen() {
  const recommendations = [
    { name: '텀블러 리필 커피', saving: '-30%', desc: '일회용 컵 대신 텀블러 사용 시 절감 가능' },
    { name: '로컬 제철 과일', saving: '-18%', desc: '수입 과일 대비 운송 탄소 절감' },
    { name: '리필형 세제', saving: '-22%', desc: '플라스틱 패키지 사용량 감소' },
  ];

  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>대체 상품 추천</Text>
        <Text style={styles.subtitle}>지금 소비 패턴 기준으로 더 나은 선택을 추천해.</Text>

        {recommendations.map((item) => (
          <View key={item.name} style={styles.card}>
            <View style={styles.row}>
              <Text style={styles.cardTitle}>{item.name}</Text>
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{item.saving}</Text>
              </View>
            </View>
            <Text style={styles.cardDesc}>{item.desc}</Text>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#FFFFFF' },
  scrollContent: { padding: 20, paddingBottom: 28 },
  title: { fontSize: 24, fontWeight: '900', color: '#1F2933', marginTop: 12, marginBottom: 6 },
  subtitle: { fontSize: 15, color: '#7A8894', marginBottom: 18 },
  card: {
    backgroundColor: '#F9F9F9',
    borderRadius: 18,
    padding: 20,
    borderWidth: 1,
    borderColor: '#ECECEC',
    marginBottom: 16,
  },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  cardTitle: { fontSize: 16, fontWeight: '800', color: '#1F2933' },
  cardDesc: { fontSize: 15, color: '#667085', lineHeight: 22, marginTop: 6 },
  badge: { backgroundColor: '#E8F7ED', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 999 },
  badgeText: { color: '#2E8B57', fontWeight: '800' },
});
