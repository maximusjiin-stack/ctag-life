import React from 'react';
import { SafeAreaView, StyleSheet, Text, View, ScrollView } from 'react-native';

export default function AnalyticsScreen() {
  const items = [
    { label: '식품', value: 46 },
    { label: '이동', value: 28 },
    { label: '소비', value: 19 },
    { label: '기타', value: 7 },
  ];

  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>탄소 분석</Text>
        <Text style={styles.subtitle}>카테고리별 소비 패턴을 한눈에 보여줘.</Text>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>카테고리별 배출 비중</Text>
          {items.map((item) => (
            <View key={item.label} style={styles.analyticsRow}>
              <View style={styles.analyticsHeader}>
                <Text style={styles.analyticsLabel}>{item.label}</Text>
                <Text style={styles.analyticsPercent}>{item.value}%</Text>
              </View>
              <View style={styles.progressTrack}>
                <View style={[styles.progressFill, { width: `${item.value}%` }]} />
              </View>
            </View>
          ))}
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>친구 대비 비교</Text>
          <Text style={styles.cardDesc}>너의 주간 평균 배출량은 친구 평균보다 12% 낮아.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#FFFFFF' },
  scrollContent: { padding: 20, paddingBottom: 28 },
  title: { fontSize: 24, fontWeight: '900', color: '#1F2933', marginTop: 12, marginBottom: 6 },
  subtitle: { fontSize: 15, color: '#7A8894', marginBottom: 18 },
  card: {
    backgroundColor: '#F9F9F9',
    borderRadius: 18,
    padding: 20,
    borderWidth: 1,
    borderColor: '#ECECEC',
    marginBottom: 16,
  },
  cardTitle: { fontSize: 16, fontWeight: '800', color: '#1F2933', marginBottom: 8 },
  cardDesc: { fontSize: 15, color: '#667085', lineHeight: 22 },
  analyticsRow: { marginBottom: 16 },
  analyticsHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  analyticsLabel: { fontSize: 15, fontWeight: '700', color: '#1F2933' },
  analyticsPercent: { fontSize: 14, color: '#2E8B57', fontWeight: '800' },
  progressTrack: {
    width: '100%',
    height: 12,
    backgroundColor: '#E7ECEA',
    borderRadius: 999,
    overflow: 'hidden',
  },
  progressFill: { height: '100%', backgroundColor: '#2E8B57', borderRadius: 999 },
});
