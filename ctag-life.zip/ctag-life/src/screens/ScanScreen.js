import React, { useState } from 'react';
import { SafeAreaView, StyleSheet, Text, View, TouchableOpacity, Alert } from 'react-native';

export default function ScanScreen() {
  const [isScanning, setIsScanning] = useState(false);
  const [result, setResult] = useState(null);

  const startScan = () => {
    setIsScanning(true);
    setResult(null);

    setTimeout(() => {
      const fakeResult = {
        store: 'Green Mart',
        carbon: '420g CO₂e',
        topItem: '플라스틱 생수 2병',
        suggestion: '다음엔 리필 스테이션 이용 시 약 18% 절감 가능',
      };
      setResult(fakeResult);
      setIsScanning(false);
      Alert.alert('스캔 완료', '영수증 분석이 끝났어.');
    }, 1800);
  };

  return (
    <SafeAreaView style={styles.screen}>
      <View style={styles.container}>
        <Text style={styles.title}>영수증 스캔</Text>
        <Text style={styles.subtitle}>구매 영수증을 프레임 안에 맞춰줘.</Text>

        <View style={styles.cameraFrame}>
          <Text style={styles.cameraPlaceholder}>
            {isScanning ? 'AI가 영수증을 읽고 탄소 데이터를 분석 중...' : '[ 카메라 / OCR 영역 ]'}
          </Text>
        </View>

        <TouchableOpacity
          style={[styles.primaryButton, isScanning && styles.disabledButton]}
          onPress={startScan}
          disabled={isScanning}
        >
          <Text style={styles.primaryButtonText}>{isScanning ? '분석 중...' : '영수증 스캔하기'}</Text>
        </TouchableOpacity>

        {result && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>분석 결과</Text>
            <Text style={styles.resultText}>매장: {result.store}</Text>
            <Text style={styles.resultText}>총 탄소 추정치: {result.carbon}</Text>
            <Text style={styles.resultText}>주요 배출 항목: {result.topItem}</Text>
            <Text style={styles.resultHint}>{result.suggestion}</Text>
          </View>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#FFFFFF' },
  container: { flex: 1, padding: 20, alignItems: 'center' },
  title: { fontSize: 24, fontWeight: '900', color: '#1F2933', marginTop: 12, marginBottom: 6 },
  subtitle: { fontSize: 15, color: '#7A8894', marginBottom: 28, textAlign: 'center' },
  cameraFrame: {
    width: '100%',
    height: 360,
    backgroundColor: '#F5F7F7',
    borderRadius: 24,
    borderWidth: 2,
    borderColor: '#2E8B57',
    borderStyle: 'dashed',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
    paddingHorizontal: 24,
  },
  cameraPlaceholder: { color: '#6B7280', fontSize: 16, textAlign: 'center', lineHeight: 24 },
  primaryButton: {
    backgroundColor: '#2E8B57',
    paddingVertical: 18,
    width: '100%',
    borderRadius: 999,
    alignItems: 'center',
  },
  disabledButton: { backgroundColor: '#A7B0B5' },
  primaryButtonText: { color: '#FFFFFF', fontSize: 18, fontWeight: '800' },
  card: {
    width: '100%',
    backgroundColor: '#F9F9F9',
    borderRadius: 18,
    padding: 20,
    borderWidth: 1,
    borderColor: '#ECECEC',
    marginTop: 20,
  },
  cardTitle: { fontSize: 16, fontWeight: '800', color: '#1F2933', marginBottom: 8 },
  resultText: { fontSize: 15, color: '#334155', marginBottom: 6 },
  resultHint: { marginTop: 8, color: '#2E8B57', fontWeight: '700', lineHeight: 22 },
});
