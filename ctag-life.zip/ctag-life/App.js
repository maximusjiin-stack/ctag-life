import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import HomeScreen from './src/screens/HomeScreen';
import AnalyticsScreen from './src/screens/AnalyticsScreen';
import ScanScreen from './src/screens/ScanScreen';
import RecommendScreen from './src/screens/RecommendScreen';
import RewardScreen from './src/screens/RewardScreen';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: '#2E8B57',
          tabBarInactiveTintColor: '#9AA3A7',
          tabBarStyle: {
            height: 64,
            paddingBottom: 8,
            paddingTop: 8,
          },
          tabBarLabelStyle: {
            fontSize: 12,
            fontWeight: '700',
          },
        }}
      >
        <Tab.Screen name="홈" component={HomeScreen} />
        <Tab.Screen name="분석" component={AnalyticsScreen} />
        <Tab.Screen name="스캔" component={ScanScreen} />
        <Tab.Screen name="추천" component={RecommendScreen} />
        <Tab.Screen name="리워드" component={RewardScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
