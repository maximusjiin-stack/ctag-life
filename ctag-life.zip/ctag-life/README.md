# CTAG LIFE

바로 실행용 Expo 앱 프로젝트야.

## 실행 방법

```bash
npm install
npx expo start
```

휴대폰 Expo Go 앱 또는 웹 브라우저로 확인하면 돼.

## 포함 화면
- 홈
- 분석
- 스캔
- 추천
- 리워드

## 참고
지금 스캔 화면은 실제 카메라/OCR 연동 전 단계라서 더미 데이터로 동작해.
